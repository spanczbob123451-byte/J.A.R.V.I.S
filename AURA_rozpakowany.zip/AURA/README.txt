A.U.R.A. — wersja webowa

Uruchom:
1. Rozpakuj ZIP.
2. Otwórz index.html w przeglądarce.

Telefon:
Najlepiej wrzucić folder na hosting statyczny, np. GitHub Pages, Netlify albo Vercel.
Po otwarciu strony w Safari/Chrome można dodać AURĘ do ekranu głównego.

Funkcje:
- czat tekstowy bez mikrofonu
- godzina i data
- kalkulator
- pogoda przez Open-Meteo
- odpowiedzi z Wikipedii
- Google i YouTube
- notatnik zapisujący dane lokalnie
- PWA / możliwość instalacji jako aplikacja

Uwaga:
Pogoda i Wikipedia wymagają internetu.
